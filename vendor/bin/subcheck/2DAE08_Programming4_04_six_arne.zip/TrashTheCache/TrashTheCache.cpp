// TrashTheCache.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <chrono>
#include <vector>
#include <functional>
#include <algorithm>
#include <numeric>
#include <map>

struct Transform
{
	float matrix[16]
	{
		1,0,0,0,
		0,1,0,0,
		0,0,1,0,
		0,0,0,1
	};
};

class GameObject3D
{
public:
	GameObject3D(int id)
		:ID{ id }
	{

	}
	Transform transform;
	int ID;
};

class GameObject3DAlt
{
public:
	GameObject3DAlt(int id)
		:ID{ id }
	{
	}
	std::unique_ptr<Transform> transform{ std::make_unique<Transform>() };
	int ID;
};

void ex1()
{
	auto integerBuffer = std::vector<int>((int)std::pow(2, 26));

	std::map<int, std::vector<long long>> sampleData{};

	size_t sampleCount{ 10 };
	for (size_t sampleIndex{}; sampleIndex < sampleCount; ++sampleIndex)
	{
		for (size_t step{ 1 }; step <= 1024; step *= 2)
		{
			const auto start = std::chrono::high_resolution_clock::now();

			for (size_t j{}; j < integerBuffer.size(); j += step)
			{
				integerBuffer[j] *= 2;
			}
			const auto end = std::chrono::high_resolution_clock::now();
			const auto total = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();

			if (sampleData.count((int)step) == 0)
			{
				sampleData[(int)step] = std::vector<long long>{};
			}
			sampleData[(int)step].push_back(total);
		}
	}

	for (auto data : sampleData)
	{
		data.second.erase(std::max_element(begin(data.second), end(data.second)));
		data.second.erase(std::min_element(begin(data.second), end(data.second)));

		auto total{ std::accumulate(begin(data.second), end(data.second),0LL, std::plus<long long>()) };
		double average{ total / (double)sampleCount };

		std::printf("%f\n", average);
	}
	std::cout << std::endl;
}

void ex2()
{
	//std::cout << sizeof(double long) << std::endl;

	std::vector<GameObject3D*> arr((int)std::pow(2, 26));

	for (size_t i{}; i < arr.size(); ++i)
	{
		arr[i] = new GameObject3D{ (int)i };
	}
	std::map<int, std::vector<long long>> sampleData{};
	size_t sampleCount{ 10 };
	for (size_t sampleIndex{}; sampleIndex < sampleCount; ++sampleIndex)
	{
		for (size_t stepsize{ 1 }; stepsize <= 1024; stepsize *= 2)
		{
			auto start = std::chrono::high_resolution_clock::now();

			for (size_t i{}; i < arr.size(); i += stepsize)
			{
				arr[i]->ID *= 2;
			}

			auto end = std::chrono::high_resolution_clock::now();
			auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();


			if (sampleData.count((int)stepsize) == 0)
			{
				sampleData[(int)stepsize] = std::vector<long long>{};
			}
			sampleData[(int)stepsize].push_back(elapsed);
		}
	}

	for (auto data : sampleData)
	{
		data.second.erase(std::max_element(begin(data.second), end(data.second)));
		data.second.erase(std::min_element(begin(data.second), end(data.second)));

		auto total{ std::accumulate(begin(data.second), end(data.second),0LL, std::plus<long long>()) };
		double average{ total / (double)sampleCount };

		std::printf("%f\n", average);
	}
	std::cout << std::endl;
}

void ex2alt()
{
	std::vector<GameObject3DAlt*> arr((int)std::pow(2, 26));

	for (size_t i{}; i < arr.size(); ++i)
	{
		arr[i] = new GameObject3DAlt{ (int)i };
	}
	std::map<int, std::vector<long long>> sampleData{};
	size_t sampleCount{ 10 };
	for (size_t sampleIndex{}; sampleIndex < sampleCount; ++sampleIndex)
	{
		for (size_t stepsize{ 1 }; stepsize <= 1024; stepsize *= 2)
		{
			auto start = std::chrono::high_resolution_clock::now();

			for (size_t i{}; i < arr.size(); i += stepsize)
			{
				arr[i]->ID *= 2;
			}

			auto end = std::chrono::high_resolution_clock::now();
			auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();


			if (sampleData.count((int)stepsize) == 0)
			{
				sampleData[(int)stepsize] = std::vector<long long>{};
			}
			sampleData[(int)stepsize].push_back(elapsed);
		}
	}

	for (auto data : sampleData)
	{
		data.second.erase(std::max_element(begin(data.second), end(data.second)));
		data.second.erase(std::min_element(begin(data.second), end(data.second)));

		auto total{ std::accumulate(begin(data.second), end(data.second),0LL, std::plus<long long>()) };
		double average{ total / (double)sampleCount };

		std::printf("%f\n", average);
	}
	std::cout << std::endl;
}

int main()
{
	//ex1();
	//ex2();
	ex2alt();
}
